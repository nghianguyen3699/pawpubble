function hidden(header, footer) {
    header.classList.add('hidden');
    footer.classList.add('hidden');
}


export { hidden };